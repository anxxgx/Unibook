<?php if(session_status() === PHP_SESSION_NONE){ session_start(); } ?>

<?php if(isset($_SESSION['id_usuario'])){ ?>

    <?php include "views/partials/navbar.php"; ?>

<?php }else{ ?>

    <nav class="navbar ub-nav">
        <div class="container justify-content-between">
            <a class="navbar-brand" href="index.php">
                <span class="mark">📚</span> UniBook
            </a>

            <a href="index.php?accion=login" class="btn-ub btn-ub-outline on-dark btn-ub-sm">
                Iniciar sesión
            </a>
        </div>
    </nav>

<?php } ?>


<?php
/*
|--------------------------------------------------------------------------
| CATÁLOGO
|--------------------------------------------------------------------------
| Conservamos el diseño original.
|
| Disponible:
|   aparece en el catálogo principal.
|
| Reservado:
|   aparece en una sección aparte debajo de los disponibles.
|
| Vendido / Intercambiado:
|   no aparece en el catálogo.
|   Estos libros quedarán para la sección Historia.
|--------------------------------------------------------------------------
*/

$librosDisponibles = [];
$librosReservados = [];

while($libro = $datos->fetch_assoc()){

    $disponibilidad = $libro['estado_disponibilidad'] ?? 'disponible';

    if($disponibilidad === 'disponible'){
        $librosDisponibles[] = $libro;
    }elseif($disponibilidad === 'reservado'){
        $librosReservados[] = $libro;
    }
}

$totalLibrosCatalogo = count($librosDisponibles);
$totalReservados = count($librosReservados);
?>


<!-- =========================================================
     HERO DEL CATÁLOGO
     ========================================================= -->

<section class="catalog-hero">
    <div class="container">

        <div class="catalog-hero__inner reveal">

            <span class="ub-eyebrow on-dark">
                381.46 — Catálogo general
            </span>

            <h1 class="catalog-hero__title">
                Encuentra tu próximo <em>libro de texto.</em>
            </h1>

            <p class="catalog-hero__lead">
                <?php echo $totalLibrosCatalogo; ?> publicaciones activas de estudiantes
                de distintas universidades y carreras de Medellín.
            </p>

            <div class="catalog-search">

                <span class="catalog-search__icon" aria-hidden="true">
                    🔍
                </span>

                <input
                    type="text"
                    id="buscador"
                    class="catalog-search__input"
                    placeholder="Buscar por título, autor o materia..."
                >

            </div>

        </div>

    </div>
</section>


<div class="ub-section">

    <div class="container">

        <div class="catalog-toolbar reveal">

            <p class="catalog-count" id="catalogoContador">
                Mostrando <b><?php echo $totalLibrosCatalogo; ?></b>
                <?php echo $totalLibrosCatalogo == 1 ? 'libro' : 'libros'; ?>
            </p>

        </div>


        <!-- =====================================================
             LIBROS DISPONIBLES
             ===================================================== -->

        <div class="row" id="contenedorLibros">

            <?php foreach($librosDisponibles as $libro){ ?>

                <div
                    class="col-md-4 mb-4 libro-card reveal"
                    data-titulo="<?php echo strtolower(htmlspecialchars($libro['titulo'])); ?>"
                    data-autor="<?php echo strtolower(htmlspecialchars($libro['autor'])); ?>"
                    data-materia="<?php echo strtolower(htmlspecialchars($libro['materia'])); ?>"
                >

                    <div class="book-card">

                        <?php

                        $tipo = strtolower($libro['tipo_publicacion']);

                        $stampClass =
                            $tipo === 'venta'
                                ? 'stamp-venta'
                                : (
                                    $tipo === 'intercambio'
                                        ? 'stamp-intercambio'
                                        : 'stamp-prestamo'
                                );

                        $tagClass = str_replace('stamp-', 'tag-', $stampClass);

                        ?>


                        <div class="cover">

                            <span class="tag <?php echo $tagClass; ?>">
                                <?php echo htmlspecialchars($libro['tipo_publicacion']); ?>
                            </span>


                            <?php if(!empty($libro['imagen'])){ ?>

                                <img
                                    src="<?php echo htmlspecialchars($libro['imagen']); ?>"
                                    alt="<?php echo htmlspecialchars($libro['titulo']); ?>"
                                    loading="lazy"
                                >

                            <?php }else{ ?>

                                <div class="no-image">
                                    Sin portada
                                </div>

                            <?php } ?>

                        </div>


                        <div class="body">

                            <h5>
                                <?php echo htmlspecialchars($libro['titulo']); ?>
                            </h5>

                            <div class="meta-row">

                                <span>
                                    👨 <b>
                                        <?php echo htmlspecialchars($libro['autor']); ?>
                                    </b>
                                </span>

                                <span>
                                    🏫 <?php echo htmlspecialchars($libro['universidad']); ?>
                                </span>

                                <span>
                                    🎓
                                    <?php echo htmlspecialchars($libro['carrera']); ?>
                                    · Sem.
                                    <?php echo htmlspecialchars($libro['semestre']); ?>
                                </span>

                                <span>
                                    📖 <?php echo htmlspecialchars($libro['materia']); ?>
                                </span>

                            </div>


                            <div class="price">
                                $<?php echo number_format($libro['precio']); ?>
                            </div>

                        </div>


                        <div class="footer">

                            <a
                                href="index.php?accion=detalle_libro&id=<?php echo (int)$libro['id']; ?>"
                                class="btn-ub btn-ub-dark btn-ub-block"
                            >
                                Ver detalles
                            </a>

                        </div>

                    </div>

                </div>

            <?php } ?>

        </div>


        <!-- =====================================================
             SIN RESULTADOS DE BÚSQUEDA
             ===================================================== -->

        <div
            class="catalog-empty"
            id="catalogoVacio"
            style="display:none;"
        >

            <div class="catalog-empty__icon">
                📭
            </div>

            <h5 class="fw-bold mb-1">
                No encontramos libros con esa búsqueda
            </h5>

            <p class="text-muted mb-0">
                Intenta con otro título, autor o materia.
            </p>

        </div>


        <!-- =====================================================
             LIBROS RESERVADOS
             ===================================================== -->

        <?php if($totalReservados > 0){ ?>

            <div
                class="catalog-toolbar reveal"
                style="margin-top: 55px;"
            >

                <p class="catalog-count">
                    <b><?php echo $totalReservados; ?></b>
                    <?php echo $totalReservados == 1 ? 'libro reservado' : 'libros reservados'; ?>
                </p>

            </div>


            <div class="row">

                <?php foreach($librosReservados as $libro){ ?>

                    <div
                        class="col-md-4 mb-4 libro-card reveal"
                        data-titulo="<?php echo strtolower(htmlspecialchars($libro['titulo'])); ?>"
                        data-autor="<?php echo strtolower(htmlspecialchars($libro['autor'])); ?>"
                        data-materia="<?php echo strtolower(htmlspecialchars($libro['materia'])); ?>"
                    >

                        <div class="book-card">

                            <?php

                            $tipo = strtolower($libro['tipo_publicacion']);

                            $stampClass =
                                $tipo === 'venta'
                                    ? 'stamp-venta'
                                    : (
                                        $tipo === 'intercambio'
                                            ? 'stamp-intercambio'
                                            : 'stamp-prestamo'
                                    );

                            $tagClass = str_replace('stamp-', 'tag-', $stampClass);

                            ?>


                            <div class="cover cover--unavailable">

                                <span class="tag <?php echo $tagClass; ?>">
                                    <?php echo htmlspecialchars($libro['tipo_publicacion']); ?>
                                </span>


                                <?php if(!empty($libro['imagen'])){ ?>

                                    <img
                                        src="<?php echo htmlspecialchars($libro['imagen']); ?>"
                                        alt="<?php echo htmlspecialchars($libro['titulo']); ?>"
                                        loading="lazy"
                                    >

                                <?php }else{ ?>

                                    <div class="no-image">
                                        Sin portada
                                    </div>

                                <?php } ?>


                                <div class="cover__overlay">

                                    <span class="stamp badge-disp-reservado">
                                        Reservado
                                    </span>

                                </div>

                            </div>


                            <div class="body">

                                <h5>
                                    <?php echo htmlspecialchars($libro['titulo']); ?>
                                </h5>

                                <div class="meta-row">

                                    <span>
                                        👨 <b>
                                            <?php echo htmlspecialchars($libro['autor']); ?>
                                        </b>
                                    </span>

                                    <span>
                                        🏫
                                        <?php echo htmlspecialchars($libro['universidad']); ?>
                                    </span>

                                    <span>
                                        🎓
                                        <?php echo htmlspecialchars($libro['carrera']); ?>
                                        · Sem.
                                        <?php echo htmlspecialchars($libro['semestre']); ?>
                                    </span>

                                    <span>
                                        📖
                                        <?php echo htmlspecialchars($libro['materia']); ?>
                                    </span>

                                </div>


                                <div class="price">
                                    $<?php echo number_format($libro['precio']); ?>
                                </div>

                            </div>


                            <div class="footer">

                                <a
                                    href="index.php?accion=detalle_libro&id=<?php echo (int)$libro['id']; ?>"
                                    class="btn-ub btn-ub-dark btn-ub-block"
                                >
                                    Ver detalles
                                </a>

                            </div>

                        </div>

                    </div>

                <?php } ?>

            </div>

        <?php } ?>


    </div>

</div>


<?php include "views/partials/footer.php"; ?>