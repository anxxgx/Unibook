<nav class="navbar navbar-expand-lg navbar-dark ub-nav">

    <div class="container">

        <a class="navbar-brand" href="index.php?accion=dashboard">
            <span class="mark">📚</span> UniBook
        </a>

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#menu">

            <span class="navbar-toggler-icon"></span>

        </button>

        <div class="collapse navbar-collapse" id="menu">

            <ul class="navbar-nav ms-auto align-items-lg-center">

                <li class="nav-item">
                    <a class="nav-link" href="index.php?accion=catalogo">
                        📚 Catálogo
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="index.php?accion=publicar_libro">
                        ➕ Publicar
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="index.php?accion=mis_compras">
                        🛒 Mis compras
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="index.php?accion=mis_ventas">
                        💰 Mis ventas
                    </a>
                </li>

                <li class="nav-item dropdown">

                    <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        role="button"
                        data-bs-toggle="dropdown">

                        🔄 Intercambios

                    </a>

                    <ul class="dropdown-menu">

                        <li>
                            <a
                                class="dropdown-item"
                                href="index.php?accion=intercambios_enviados">

                                Solicitudes enviadas

                            </a>
                        </li>

                        <li>
                            <a
                                class="dropdown-item"
                                href="index.php?accion=intercambios_recibidos">

                                Solicitudes recibidas

                            </a>
                        </li>

                    </ul>

                </li>

                <?php

                $notificacionesPendientes = 0;

                if (
                    isset($_SESSION['id_usuario']) &&
                    isset($notificacionController)
                ) {
                    $notificacionesPendientes =
                        $notificacionController->contarNoLeidas();
                }

                ?>

                <li class="nav-item">

                    <a
                        class="nav-link position-relative"
                        href="index.php?accion=notificaciones">

                        🔔 Notificaciones

                        <?php if ($notificacionesPendientes > 0): ?>

                            <span
                                class="badge bg-danger rounded-pill ms-1">

                                <?php
                                echo $notificacionesPendientes;
                                ?>

                            </span>

                        <?php endif; ?>

                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link"
                        href="index.php?accion=perfil">

                        👤 Mi perfil

                    </a>

                </li>

                <li class="nav-item ms-lg-3 mt-2 mt-lg-0">

                    <a
                        href="logout.php"
                        class="btn-ub btn-ub-outline on-dark btn-ub-sm">

                        Cerrar sesión

                    </a>

                </li>

            </ul>

        </div>

    </div>

</nav>